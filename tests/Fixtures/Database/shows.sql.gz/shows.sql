-- MySQL dump 10.13  Distrib 9.5.0, for macos15.7 (arm64)
--
-- Host: 127.0.0.1    Database: marseille_v1
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `shows`
--
-- WHERE:  1=1 ORDER BY _tmdb_popularity DESC LIMIT 2

LOCK TABLES `shows` WRITE;
/*!40000 ALTER TABLE `shows` DISABLE KEYS */;
INSERT INTO `shows` (`id`, `_imdb_id`, `_imdb_num_votes`, `_imdb_average_rating`, `created_at`, `updated_at`, `_tmdb_id`, `_tmdb_name`, `_tmdb_original_name`, `_tmdb_original_language`, `_tmdb_overview`, `_tmdb_tagline`, `_tmdb_status`, `_tmdb_first_air_date`, `_tmdb_popularity`, `_tmdb_vote_average`, `_tmdb_vote_count`, `_tmdb_genres`, `_tmdb_poster_path`, `_tmdb_backdrop_path`, `_tmdb_external_ids`, `tmdb_synced_at`, `_tvdb_id`, `_tvdb_name`, `_tvdb_slug`, `_tvdb_overview`, `_tvdb_score`, `_tvdb_firstAired`, `_tvdb_lastAired`, `_tvdb_year`, `_tvdb_averageRuntime`, `_tvdb_status`, `_tvdb_originalLanguage`, `_tvdb_originalCountry`, `_tvdb_genres`, `_tvdb_remoteIds`, `tvdb_synced_at`, `_tvdb_defaultSeasonType`, `episodes_synced_at`) VALUES (25647,'tt0853076',310,3.2,'2026-07-23 09:39:39','2026-07-23 12:05:39',27181,'Rote Rosen','Rote Rosen','de','Rote Rosen is a German telenovela produced by Studio Hamburg Serienwerft Lüneburg and broadcast by Das Erste since November 6, 2006. The show is a complex telenovela, who tells one love story every season about women in their forties.','','Returning Series','2006-11-06',399.5203,2.583,6,'[{\"id\": 10766, \"name\": \"Soap\"}, {\"id\": 18, \"name\": \"Drama\"}]','/swL2qUjGrChFyj14ExwA0pwWtzv.jpg','/qZ1odCAlNZhUIeLXZXU06JxRqjo.jpg','{\"imdb_id\": \"tt0853076\", \"tvdb_id\": 255974, \"tvrage_id\": null, \"twitter_id\": null, \"facebook_id\": \"RoteRosen\", \"freebase_id\": null, \"wikidata_id\": \"Q471627\", \"freebase_mid\": \"/m/07cgqnh\", \"instagram_id\": \"rote_rosen\"}','2026-07-23 12:05:39',255974,'Rote Rosen','red-roses','Die Telenovela beginnt 2006 mit der gescheiterten Ehe von Petra Jansen (Angela Roy) und ihrem Mann Thomas (Gerry Hungbauer), nachdem dieser seine Frau mit der Freundin ihrer älteren Tochter betrogen hatte. Seit dem werden immer wieder neue Beziehungsgeschichten miteinander verwoben, die sich rund um das fiktive Lüneburger Fünfsternehotel „Drei Könige“, das zugehörige Restaurant „Carlas“, das Mietshaus „Rosenhaus“, die Gärtnerei Albers sowie die Arbeitsorte der jeweiligen Staffelhauptfiguren abspielen. In jeder Staffel werden zahlreiche Charaktere durch neue Protagonisten aller Altersklassen ersetzt, die um eine weibliche Hauptfigur angesiedelt sind und mit ihren zwischenmenschlichen Verwicklungen sowie beruflichen und privaten Selbstverwirklichungen den Stoff für weitere Folgen liefern.',633,'2006-11-06','2026-08-24','2006',50,'{\"id\": 1, \"name\": \"Continuing\", \"recordType\": \"series\", \"keepUpdated\": true}','deu','deu','[{\"id\": 1, \"name\": \"Soap\", \"slug\": \"soap\"}, {\"id\": 12, \"name\": \"Drama\", \"slug\": \"drama\"}]','[{\"id\": \"tt0853076\", \"type\": 2, \"sourceName\": \"IMDB\"}, {\"id\": \"27181\", \"type\": 12, \"sourceName\": \"TheMovieDB.com\"}]','2026-07-23 09:39:39',1,NULL),(89725,'tt11198330',548907,8.3,'2026-07-23 11:31:51','2026-07-23 12:54:39',94997,'House of the Dragon','House of the Dragon','en','The Targaryen dynasty is at the absolute apex of its power, with more than 15 dragons under their yoke. Most empires crumble from such heights. In the case of the Targaryens, their slow fall begins when King Viserys breaks with a century of tradition by naming his daughter Rhaenyra heir to the Iron Throne. But when Viserys later fathers a son, the court is shocked when Rhaenyra retains her status as his heir, and seeds of division sow friction across the realm.','Win or die.','Returning Series','2022-08-21',375.4991,8.371,6684,'[{\"id\": 10765, \"name\": \"Sci-Fi & Fantasy\"}, {\"id\": 18, \"name\": \"Drama\"}, {\"id\": 10759, \"name\": \"Action & Adventure\"}]','/7V0Ebks0GgpKvQ7QbLAIdX5dos4.jpg','/577eXC8wFQT0eUrJcgznSiFPRmk.jpg','{\"imdb_id\": \"tt11198330\", \"tvdb_id\": 371572, \"tvrage_id\": 0, \"twitter_id\": \"HouseofDragon\", \"facebook_id\": \"100067234122352\", \"freebase_id\": \"\", \"wikidata_id\": \"Q72930269\", \"freebase_mid\": \"\", \"instagram_id\": \"houseofthedragonhbo\"}','2026-07-23 12:54:39',371572,'House of the Dragon','house-of-the-dragon','The story of House Targaryen, 200 years before the events of Game of Thrones.',1808173,'2022-08-21','2026-08-09','2022',62,'{\"id\": 1, \"name\": \"Continuing\", \"recordType\": \"series\", \"keepUpdated\": true}','eng','usa','[{\"id\": 10, \"name\": \"Fantasy\", \"slug\": \"fantasy\"}, {\"id\": 12, \"name\": \"Drama\", \"slug\": \"drama\"}, {\"id\": 18, \"name\": \"Adventure\", \"slug\": \"adventure\"}, {\"id\": 19, \"name\": \"Action\", \"slug\": \"action\"}, {\"id\": 34, \"name\": \"War\", \"slug\": \"war\"}]','[{\"id\": \"10.5240/3D7A-ADBA-656C-E7D8-604D-X\", \"type\": 13, \"sourceName\": \"EIDR\"}, {\"id\": \"houseofthedragon\", \"type\": 5, \"sourceName\": \"Facebook\"}, {\"id\": \"tt11198330\", \"type\": 2, \"sourceName\": \"IMDB\"}, {\"id\": \"houseofthedragonhbo\", \"type\": 9, \"sourceName\": \"Instagram\"}, {\"id\": \"https://www.hbo.com/house-of-the-dragon\", \"type\": 4, \"sourceName\": \"Official Website\"}, {\"id\": \"HouseOfTheDragon\", \"type\": 7, \"sourceName\": \"Reddit\"}, {\"id\": \"94997\", \"type\": 12, \"sourceName\": \"TheMovieDB.com\"}, {\"id\": \"44778\", \"type\": 19, \"sourceName\": \"TV Maze\"}, {\"id\": \"HouseofDragon\", \"type\": 6, \"sourceName\": \"X (Twitter)\"}, {\"id\": \"Q72930269\", \"type\": 18, \"sourceName\": \"Wikidata\"}, {\"id\": \"House_of_the_Dragon\", \"type\": 24, \"sourceName\": \"Wikipedia\"}, {\"id\": \"hbomax\", \"type\": 11, \"sourceName\": \"Youtube\"}]','2026-07-23 11:31:51',1,NULL);
/*!40000 ALTER TABLE `shows` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-23 17:13:15
