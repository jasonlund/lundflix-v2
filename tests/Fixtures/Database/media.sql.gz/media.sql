-- MySQL dump 10.13  Distrib 9.5.0, for macos15.7 (arm64)
--
-- Host: 127.0.0.1    Database: marseille_v1
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `media`
--
-- WHERE:  1=1 ORDER BY id LIMIT 2

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` (`id`, `mediable_type`, `mediable_id`, `type`, `is_active`, `_tmdb_file_path`, `_tmdb_iso_639_1`, `_tmdb_iso_3166_1`, `_tmdb_vote_average`, `_tmdb_vote_count`, `_tmdb_width`, `_tmdb_height`, `_tmdb_aspect_ratio`, `created_at`, `updated_at`, `_tvdb_image`, `_tvdb_type`, `_tvdb_language`, `_tvdb_width`, `_tvdb_height`, `_tvdb_score`, `_tvdb_thumbnail`) VALUES (1,'movie',1,'poster',1,'/zBiHKhXklvTFwj4M1uEUcQGAVJ.jpg','en','US',0.166,2,1000,1500,0.667,'2026-07-22 11:23:09','2026-07-22 11:23:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'movie',1,'poster',1,'/sPxxz8mFpJ1lAfxRxvDMy9SxojC.jpg',NULL,NULL,3.334,1,2000,3000,0.667,'2026-07-22 11:23:09','2026-07-22 11:23:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-23 17:13:15
