-- MySQL dump 10.13  Distrib 9.5.0, for macos15.7 (arm64)
--
-- Host: 127.0.0.1    Database: marseille_v1
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `downloads`
--
-- WHERE:  1=1 ORDER BY _provider_availability DESC LIMIT 2

LOCK TABLES `downloads` WRITE;
/*!40000 ALTER TABLE `downloads` DISABLE KEYS */;
INSERT INTO `downloads` (`id`, `_imdb_id`, `_tmdb_id`, `_provider_id`, `_provider_name`, `_provider_filename`, `_provider_category`, `_provider_subcategory`, `_provider_size_bytes`, `_provider_availability`, `_provider_demand`, `_provider_uploader`, `_provider_published_at`, `_provider_files`, `_provider_description`, `quality`, `codec`, `source`, `release_tag`, `is_rar`, `index_synced_at`, `rss_synced_at`, `detail_synced_at`, `filelist_synced_at`, `created_at`, `updated_at`) VALUES (2855,NULL,NULL,7564277,'Backrooms 2026 1080p AMZN WEB-DL DDP5 1 Atmos H 264-BYNDR','Backrooms 2026 1080p AMZN WEB-DL DDP5 1 Atmos H 264-BYNDR','72','Movie/HD/Bluray',7913477243,5728,8,'Lama',NULL,NULL,NULL,'1080p','x264','web-dl','none',1,'2026-07-23 21:19:41',NULL,NULL,NULL,'2026-07-23 21:19:41','2026-07-23 21:19:41'),(357892,NULL,NULL,7562376,'Rick and Morty S09E08 1080p WEB h264-EDITH','Rick.and.Morty.S09E08.1080p.WEB.h264-EDITH','73','TV/Web-DL',746586112,5092,10,'TvTeam',NULL,NULL,NULL,'1080p','x264','web','none',1,'2026-07-23 23:20:02',NULL,NULL,NULL,'2026-07-23 23:20:02','2026-07-23 23:20:02');
/*!40000 ALTER TABLE `downloads` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-23 17:13:16
